/*   */ package Decoder;
/*   */ 
/*   */ import java.io.IOException;
/*   */ 
/*   */ public class CEFormatException
/*   */   extends IOException
/*   */ {
/*   */   public CEFormatException(String s) {
/* 9 */     super(s);
/*   */   }
/*   */ }


/* Location:              D:\demo\encryption-master\sun.misc.BASE64Decoder.jar!\Decoder\CEFormatException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */