package Decoder;

import java.io.IOException;

public class CEStreamExhausted extends IOException {}


/* Location:              D:\demo\encryption-master\sun.misc.BASE64Decoder.jar!\Decoder\CEStreamExhausted.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */