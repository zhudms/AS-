/*     */ package Decoder;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CharacterDecoder
/*     */ {
/*     */   protected abstract int bytesPerAtom();
/*     */   
/*     */   protected abstract int bytesPerLine();
/*     */   
/*     */   protected void decodeBufferPrefix(PushbackInputStream aStream, OutputStream bStream) throws IOException {}
/*     */   
/*     */   protected void decodeBufferSuffix(PushbackInputStream aStream, OutputStream bStream) throws IOException {}
/*     */   
/*     */   protected int decodeLinePrefix(PushbackInputStream aStream, OutputStream bStream) throws IOException {
/* 111 */     return bytesPerLine();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void decodeLineSuffix(PushbackInputStream aStream, OutputStream bStream) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void decodeAtom(PushbackInputStream aStream, OutputStream bStream, int l) throws IOException {
/* 134 */     throw new CEStreamExhausted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int readFully(InputStream in, byte[] buffer, int offset, int len) throws IOException {
/* 144 */     for (int i = 0; i < len; i++) {
/*     */       
/* 146 */       int q = in.read();
/* 147 */       if (q == -1)
/* 148 */         return (i == 0) ? -1 : i; 
/* 149 */       buffer[i + offset] = (byte)q;
/*     */     } 
/* 151 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeBuffer(InputStream aStream, OutputStream bStream) throws IOException {
/* 165 */     int totalBytes = 0;
/*     */     
/* 167 */     PushbackInputStream ps = new PushbackInputStream(aStream);
/* 168 */     decodeBufferPrefix(ps, bStream);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */       while (true)
/* 175 */       { int length = decodeLinePrefix(ps, bStream); int i;
/* 176 */         for (i = 0; i + bytesPerAtom() < length; i += bytesPerAtom()) {
/*     */           
/* 178 */           decodeAtom(ps, bStream, bytesPerAtom());
/* 179 */           totalBytes += bytesPerAtom();
/*     */         } 
/* 181 */         if (i + bytesPerAtom() == length) {
/*     */           
/* 183 */           decodeAtom(ps, bStream, bytesPerAtom());
/* 184 */           totalBytes += bytesPerAtom();
/*     */         } else {
/*     */           
/* 187 */           decodeAtom(ps, bStream, length - i);
/* 188 */           totalBytes += length - i;
/*     */         } 
/* 190 */         decodeLineSuffix(ps, bStream); } 
/* 191 */     } catch (CEStreamExhausted cEStreamExhausted) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 196 */       decodeBufferSuffix(ps, bStream);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decodeBuffer(String inputString) throws IOException {
/* 206 */     byte[] inputBuffer = new byte[inputString.length()];
/*     */ 
/*     */ 
/*     */     
/* 210 */     inputString.getBytes(0, inputString.length(), inputBuffer, 0);
/* 211 */     ByteArrayInputStream inStream = new ByteArrayInputStream(inputBuffer);
/* 212 */     ByteArrayOutputStream outStream = new ByteArrayOutputStream();
/* 213 */     decodeBuffer(inStream, outStream);
/* 214 */     return outStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decodeBuffer(InputStream in) throws IOException {
/* 222 */     ByteArrayOutputStream outStream = new ByteArrayOutputStream();
/* 223 */     decodeBuffer(in, outStream);
/* 224 */     return outStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer decodeBufferToByteBuffer(String inputString) throws IOException {
/* 233 */     return ByteBuffer.wrap(decodeBuffer(inputString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer decodeBufferToByteBuffer(InputStream in) throws IOException {
/* 242 */     return ByteBuffer.wrap(decodeBuffer(in));
/*     */   }
/*     */ }


/* Location:              D:\demo\encryption-master\sun.misc.BASE64Decoder.jar!\Decoder\CharacterDecoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */