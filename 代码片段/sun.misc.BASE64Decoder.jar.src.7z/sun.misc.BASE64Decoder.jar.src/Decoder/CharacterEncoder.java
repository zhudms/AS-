/*     */ package Decoder;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CharacterEncoder
/*     */ {
/*     */   protected PrintStream pStream;
/*     */   
/*     */   protected abstract int bytesPerAtom();
/*     */   
/*     */   protected abstract int bytesPerLine();
/*     */   
/*     */   protected void encodeBufferPrefix(OutputStream aStream) throws IOException {
/*  86 */     this.pStream = new PrintStream(aStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encodeBufferSuffix(OutputStream aStream) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encodeLinePrefix(OutputStream aStream, int aLength) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encodeLineSuffix(OutputStream aStream) throws IOException {
/* 110 */     this.pStream.println();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void encodeAtom(OutputStream paramOutputStream, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int readFully(InputStream in, byte[] buffer) throws IOException {
/* 124 */     for (int i = 0; i < buffer.length; i++) {
/*     */       
/* 126 */       int q = in.read();
/* 127 */       if (q == -1)
/* 128 */         return i; 
/* 129 */       buffer[i] = (byte)q;
/*     */     } 
/* 131 */     return buffer.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encode(InputStream inStream, OutputStream outStream) throws IOException {
/* 145 */     byte[] tmpbuffer = new byte[bytesPerLine()];
/*     */     
/* 147 */     encodeBufferPrefix(outStream);
/*     */ 
/*     */     
/*     */     while (true) {
/* 151 */       int numBytes = readFully(inStream, tmpbuffer);
/* 152 */       if (numBytes == 0) {
/*     */         break;
/*     */       }
/*     */       
/* 156 */       encodeLinePrefix(outStream, numBytes);
/* 157 */       for (int j = 0; j < numBytes; j += bytesPerAtom()) {
/*     */ 
/*     */         
/* 160 */         if (j + bytesPerAtom() <= numBytes) {
/*     */           
/* 162 */           encodeAtom(outStream, tmpbuffer, j, bytesPerAtom());
/*     */         } else {
/*     */           
/* 165 */           encodeAtom(outStream, tmpbuffer, j, numBytes - j);
/*     */         } 
/*     */       } 
/* 168 */       if (numBytes < bytesPerLine()) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 173 */       encodeLineSuffix(outStream);
/*     */     } 
/*     */     
/* 176 */     encodeBufferSuffix(outStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encode(byte[] aBuffer, OutputStream aStream) throws IOException {
/* 185 */     ByteArrayInputStream inStream = new ByteArrayInputStream(aBuffer);
/* 186 */     encode(inStream, aStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(byte[] aBuffer) {
/* 195 */     ByteArrayOutputStream outStream = new ByteArrayOutputStream();
/* 196 */     ByteArrayInputStream inStream = new ByteArrayInputStream(aBuffer);
/* 197 */     String retVal = null;
/*     */     
/*     */     try {
/* 200 */       encode(inStream, outStream);
/*     */       
/* 202 */       retVal = outStream.toString("8859_1");
/* 203 */     } catch (Exception IOException) {
/*     */ 
/*     */       
/* 206 */       throw new Error("CharacterEncoder.encode internal error");
/*     */     } 
/* 208 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getBytes(ByteBuffer bb) {
/* 228 */     byte[] buf = (byte[])null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     if (bb.hasArray()) {
/*     */       
/* 236 */       byte[] tmp = bb.array();
/* 237 */       if (tmp.length == bb.capacity() && tmp.length == bb.remaining()) {
/*     */         
/* 239 */         buf = tmp;
/* 240 */         bb.position(bb.limit());
/*     */       } 
/*     */     } 
/*     */     
/* 244 */     if (buf == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 251 */       buf = new byte[bb.remaining()];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 256 */       bb.get(buf);
/*     */     } 
/*     */     
/* 259 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encode(ByteBuffer aBuffer, OutputStream aStream) throws IOException {
/* 272 */     byte[] buf = getBytes(aBuffer);
/* 273 */     encode(buf, aStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(ByteBuffer aBuffer) {
/* 285 */     byte[] buf = getBytes(aBuffer);
/* 286 */     return encode(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBuffer(InputStream inStream, OutputStream outStream) throws IOException {
/*     */     int numBytes;
/* 301 */     byte[] tmpbuffer = new byte[bytesPerLine()];
/*     */     
/* 303 */     encodeBufferPrefix(outStream);
/*     */ 
/*     */     
/*     */     do {
/* 307 */       numBytes = readFully(inStream, tmpbuffer);
/* 308 */       if (numBytes == 0) {
/*     */         break;
/*     */       }
/*     */       
/* 312 */       encodeLinePrefix(outStream, numBytes);
/* 313 */       for (int j = 0; j < numBytes; j += bytesPerAtom()) {
/*     */         
/* 315 */         if (j + bytesPerAtom() <= numBytes) {
/*     */           
/* 317 */           encodeAtom(outStream, tmpbuffer, j, bytesPerAtom());
/*     */         } else {
/*     */           
/* 320 */           encodeAtom(outStream, tmpbuffer, j, numBytes - j);
/*     */         } 
/*     */       } 
/* 323 */       encodeLineSuffix(outStream);
/* 324 */     } while (numBytes >= bytesPerLine());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     encodeBufferSuffix(outStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBuffer(byte[] aBuffer, OutputStream aStream) throws IOException {
/* 339 */     ByteArrayInputStream inStream = new ByteArrayInputStream(aBuffer);
/* 340 */     encodeBuffer(inStream, aStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encodeBuffer(byte[] aBuffer) {
/* 349 */     ByteArrayOutputStream outStream = new ByteArrayOutputStream();
/* 350 */     ByteArrayInputStream inStream = new ByteArrayInputStream(aBuffer);
/*     */     
/*     */     try {
/* 353 */       encodeBuffer(inStream, outStream);
/* 354 */     } catch (Exception IOException) {
/*     */ 
/*     */       
/* 357 */       throw new Error("CharacterEncoder.encodeBuffer internal error");
/*     */     } 
/* 359 */     return outStream.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBuffer(ByteBuffer aBuffer, OutputStream aStream) throws IOException {
/* 372 */     byte[] buf = getBytes(aBuffer);
/* 373 */     encodeBuffer(buf, aStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encodeBuffer(ByteBuffer aBuffer) {
/* 385 */     byte[] buf = getBytes(aBuffer);
/* 386 */     return encodeBuffer(buf);
/*     */   }
/*     */ }


/* Location:              D:\demo\encryption-master\sun.misc.BASE64Decoder.jar!\Decoder\CharacterEncoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */