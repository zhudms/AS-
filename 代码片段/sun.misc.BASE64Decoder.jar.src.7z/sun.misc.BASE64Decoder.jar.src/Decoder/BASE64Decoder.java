/*     */ package Decoder;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BASE64Decoder
/*     */   extends CharacterDecoder
/*     */ {
/*     */   protected int bytesPerAtom() {
/*  65 */     return 4;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int bytesPerLine() {
/*  70 */     return 72;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private static final char[] pem_array = new char[] {
/*     */       
/*  79 */       'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 
/*  80 */       'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
/*  81 */       'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 
/*  82 */       'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 
/*  83 */       'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
/*  84 */       'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
/*  85 */       'w', 'x', 'y', 'z', '0', '1', '2', '3', 
/*  86 */       '4', '5', '6', '7', '8', '9', '+', '/'
/*     */     };
/*     */   
/*  89 */   private static final byte[] pem_convert_array = new byte[256];
/*     */   static {
/*     */     int i;
/*  92 */     for (i = 0; i < 255; i++) {
/*  93 */       pem_convert_array[i] = -1;
/*     */     }
/*  95 */     for (i = 0; i < pem_array.length; i++)
/*  96 */       pem_convert_array[pem_array[i]] = (byte)i; 
/*     */   }
/*     */   
/*  99 */   byte[] decode_buffer = new byte[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void decodeAtom(PushbackInputStream inStream, OutputStream outStream, int rem) throws IOException {
/* 107 */     byte a = -1, b = -1, c = -1, d = -1;
/*     */     
/* 109 */     if (rem < 2) {
/* 110 */       throw new CEFormatException("BASE64Decoder: Not enough bytes for an atom.");
/*     */     }
/*     */     while (true) {
/* 113 */       int i = inStream.read();
/* 114 */       if (i == -1) {
/* 115 */         throw new CEStreamExhausted();
/*     */       }
/* 117 */       if (i != 10 && i != 13) {
/* 118 */         this.decode_buffer[0] = (byte)i;
/*     */         
/* 120 */         i = readFully(inStream, this.decode_buffer, 1, rem - 1);
/* 121 */         if (i == -1) {
/* 122 */           throw new CEStreamExhausted();
/*     */         }
/*     */         
/* 125 */         if (rem > 3 && this.decode_buffer[3] == 61) {
/* 126 */           rem = 3;
/*     */         }
/* 128 */         if (rem > 2 && this.decode_buffer[2] == 61)
/* 129 */           rem = 2;  break;
/*     */       } 
/* 131 */     }  switch (rem) {
/*     */       case 4:
/* 133 */         d = pem_convert_array[this.decode_buffer[3] & 0xFF];
/*     */       
/*     */       case 3:
/* 136 */         c = pem_convert_array[this.decode_buffer[2] & 0xFF];
/*     */       
/*     */       case 2:
/* 139 */         b = pem_convert_array[this.decode_buffer[1] & 0xFF];
/* 140 */         a = pem_convert_array[this.decode_buffer[0] & 0xFF];
/*     */         break;
/*     */     } 
/*     */     
/* 144 */     switch (rem) {
/*     */       case 2:
/* 146 */         outStream.write((byte)(a << 2 & 0xFC | b >>> 4 & 0x3));
/*     */         break;
/*     */       case 3:
/* 149 */         outStream.write((byte)(a << 2 & 0xFC | b >>> 4 & 0x3));
/* 150 */         outStream.write((byte)(b << 4 & 0xF0 | c >>> 2 & 0xF));
/*     */         break;
/*     */       case 4:
/* 153 */         outStream.write((byte)(a << 2 & 0xFC | b >>> 4 & 0x3));
/* 154 */         outStream.write((byte)(b << 4 & 0xF0 | c >>> 2 & 0xF));
/* 155 */         outStream.write((byte)(c << 6 & 0xC0 | d & 0x3F));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\demo\encryption-master\sun.misc.BASE64Decoder.jar!\Decoder\BASE64Decoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */