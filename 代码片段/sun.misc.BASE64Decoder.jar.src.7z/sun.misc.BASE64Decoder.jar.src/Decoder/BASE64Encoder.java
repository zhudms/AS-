/*     */ package Decoder;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BASE64Encoder
/*     */   extends CharacterEncoder
/*     */ {
/*     */   protected int bytesPerAtom() {
/*  51 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int bytesPerLine() {
/*  60 */     return 57;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  65 */   private static final char[] pem_array = new char[] {
/*     */       
/*  67 */       'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 
/*  68 */       'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
/*  69 */       'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 
/*  70 */       'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 
/*  71 */       'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
/*  72 */       'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
/*  73 */       'w', 'x', 'y', 'z', '0', '1', '2', '3', 
/*  74 */       '4', '5', '6', '7', '8', '9', '+', '/'
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void encodeAtom(OutputStream outStream, byte[] data, int offset, int len) throws IOException {
/*  86 */     if (len == 1) {
/*     */       
/*  88 */       byte a = data[offset];
/*  89 */       byte b = 0;
/*  90 */       byte c = 0;
/*  91 */       outStream.write(pem_array[a >>> 2 & 0x3F]);
/*  92 */       outStream.write(pem_array[(a << 4 & 0x30) + (b >>> 4 & 0xF)]);
/*  93 */       outStream.write(61);
/*  94 */       outStream.write(61);
/*  95 */     } else if (len == 2) {
/*     */       
/*  97 */       byte a = data[offset];
/*  98 */       byte b = data[offset + 1];
/*  99 */       byte c = 0;
/* 100 */       outStream.write(pem_array[a >>> 2 & 0x3F]);
/* 101 */       outStream.write(pem_array[(a << 4 & 0x30) + (b >>> 4 & 0xF)]);
/* 102 */       outStream.write(pem_array[(b << 2 & 0x3C) + (c >>> 6 & 0x3)]);
/* 103 */       outStream.write(61);
/*     */     } else {
/*     */       
/* 106 */       byte a = data[offset];
/* 107 */       byte b = data[offset + 1];
/* 108 */       byte c = data[offset + 2];
/* 109 */       outStream.write(pem_array[a >>> 2 & 0x3F]);
/* 110 */       outStream.write(pem_array[(a << 4 & 0x30) + (b >>> 4 & 0xF)]);
/* 111 */       outStream.write(pem_array[(b << 2 & 0x3C) + (c >>> 6 & 0x3)]);
/* 112 */       outStream.write(pem_array[c & 0x3F]);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\demo\encryption-master\sun.misc.BASE64Decoder.jar!\Decoder\BASE64Encoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */