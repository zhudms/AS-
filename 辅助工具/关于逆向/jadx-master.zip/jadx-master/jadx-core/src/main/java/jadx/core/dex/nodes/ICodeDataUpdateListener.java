package jadx.core.dex.nodes;

import jadx.api.data.ICodeData;

public interface ICodeDataUpdateListener {

	void updated(ICodeData codeData);
}
