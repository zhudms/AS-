package jadx.core.utils.android;

public enum AppAttribute {
	APPLICATION_LABEL,
	MIN_SDK_VERSION,
	TARGET_SDK_VERSION,
	VERSION_CODE,
	VERSION_NAME,
	MAIN_ACTIVITY,
}
