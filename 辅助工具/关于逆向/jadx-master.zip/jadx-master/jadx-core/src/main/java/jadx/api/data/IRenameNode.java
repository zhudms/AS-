package jadx.api.data;

public interface IRenameNode {

	void rename(String newName);
}
