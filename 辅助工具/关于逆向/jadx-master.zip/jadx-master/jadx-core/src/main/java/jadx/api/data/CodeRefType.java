package jadx.api.data;

public enum CodeRefType {
	MTH_ARG,
	VAR,
	CATCH,
	INSN,
}
