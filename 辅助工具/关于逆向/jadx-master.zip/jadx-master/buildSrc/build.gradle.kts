plugins {
	`kotlin-dsl`
}

dependencies {
	implementation("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.23")
}

repositories {
	gradlePluginPortal()
}
